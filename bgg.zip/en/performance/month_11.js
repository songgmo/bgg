let schedule = [
	{
		day: '1',
		week: '수 WED',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '2',
		week: '목 THU',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '3',
		week: '금 FRI',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '4',
		week: '토 SAT',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '24',
		week: '금 FRI',
		category: 'Exchange',
		title: 'Namwon National Gugak Center Exchange Performance &lt;Byeolnangakssi&gt;',
		imgSrc: '../../asset/images/performance/thumb/0603.jpg',
		inTit1: '11.24.(Fri) ~ 11.25.(Sat)  Weekdays 19:30 Weekends 17:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 10,000won A seat 8,000won',
		link: '0603.html'
	},
	{
		day: '25',
		week: '토 SAT',
		category: 'Exchange',
		title: 'Namwon National Gugak Center Exchange Performance &lt;Byeolnangakssi&gt;',
		imgSrc: '../../asset/images/performance/thumb/0603.jpg',
		inTit1: '11.24.(Fri) ~ 11.25.(Sat)  Weekdays 19:30 Weekends 17:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 10,000won A seat 8,000won',
		link: '0603.html'
	},
];