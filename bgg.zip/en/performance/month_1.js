let schedule = [
	{
		day: '7',
		week: '토 SAT',
		category: 'Special',
		title: 'New Year Concert &#60;It is GOOD!&#62;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(Sat), 1.14.(Sat), 1.28.(Sat) 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 10,000won A seat 8,000won',
		link: '0301.html'
	},
	{
		day: '14',
		week: '토 SAT',
		category: 'Special',
		title: 'New Year Concert &lt;It is GOOD!&gt;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(Sat), 1.14.(Sat), 1.28.(Sat) 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 10,000won A seat 8,000won',
		link: '0301.html'
	},
	{
		day: '21',
		week: '토 SAT',
		category: 'Seasonal',
		title: 'New Year Concert &lt;Black Rabbit Theatric Show Panpanpan&gt;',
		imgSrc: '../../asset/images/performance/thumb/0501.jpg',
		inTit1: '1.21.(Sat) ~ 1.22.(Sun) 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'All seats 10,000won',
		link: '0501.html'
	},
	{
		day: '22',
		week: '일 SUN',
		category: 'Seasonal',
		title: 'New Year Concert &lt;Black Rabbit Theatric Show Panpanpan&gt;',
		imgSrc: '../../asset/images/performance/thumb/0501.jpg',
		inTit1: '1.21.(Sat) ~ 1.22.(Sun) 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'All seats 10,000won',
		link: '0501.html'
	},
	{
		day: '28',
		week: '일 SUN',
		category: 'Special',
		title: 'New Year Concert &lt;It is GOOD!&gt;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(Sat), 1.14.(Sat), 1.28.(Sat) 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 10,000won A seat 8,000won',
		link: '0301.html'
	},
	];
	