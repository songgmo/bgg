let schedule_allyear = [

];