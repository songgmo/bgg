let schedule = [
	{
		day: '13',
		week: '금 FRI',
		category: 'Special',
		title: 'College Gugak Festival &lt;Jieum知音&gt;',
		imgSrc: '../../asset/images/performance/thumb/0306.jpg',
		inTit1: '10.13.(Fri) 19:30',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'Free',
		link: '0306.html'
	},
	{
		day: '27',
		week: '금 FRI',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '28',
		week: '토 SAT',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
	{
		day: '31',
		week: '화 TUE',
		category: 'Brand',
		title: 'Brand Concert  Dongrae(tentative)',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(Fri) ~ 11.4.(Sat)  Weekdays 19:30 Weekends 15:00',
		inTit2: 'Yeonak-dang Hall',
		inTit3: 'S seat 20,000won A seat 10,000won',
		link: '0101.html'
	},
];