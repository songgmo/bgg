let schedule = [
	{
		day: '22',
		week: '토 SAT',
		category: 'Ordinary person',
		title: 'Talk with Masters',
		imgSrc: '../../asset/images/education/thumb/0203.jpg',
		inTit1: 'Busan local resident',
		inTit2: 'Gugak Specialists',
		inTit3: 'Free',
		link: '0203.html'
	},
];