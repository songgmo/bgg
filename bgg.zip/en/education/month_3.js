let schedule = [
	{
		day: '11',
		week: '토 SAT',
		category: 'Ordinary person',
		title: '2023 the First Half Saturday Lecture, Story Festival <Deom Deom Deom(More More Better)>',
		imgSrc: '../../asset/images/education/thumb/0205.jpg',
		inTit1: 'Open to All',
		inTit2: '-',
		inTit3: 'Free',
		link: '0205.html'
	},
];