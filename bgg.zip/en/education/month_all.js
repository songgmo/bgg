let schedule_allyear = [
	{
		day: '',
		week: 'year-around',
		category: 'Teenager',
		title: 'School Support and Outreach Program',
		imgSrc: '../../asset/images/education/thumb/0301.jpg',
		inTit1: 'Elementary school students(3~6 grade)',
		inTit2: 'Busan National Gugak Center musicians, Invited instructors',
		inTit3: '100,000won',
		link: '0301.html'
	},
	{
		day: '',
		week: 'year-around',
		category: 'Ordinary person',
		title: 'Beautiful accompaniment with Gugak',
		imgSrc: '../../asset/images/education/thumb/0204.jpg',
		inTit1: 'Children and seniors in welfare agency',
		inTit2: 'Invited instructors',
		inTit3: 'Free',
		link: '0204.html'
	},
	{
		day: '',
		week: 'year-around',
		category: 'Foreigner',
		title: 'One Day Gugak Experience',
		imgSrc: '../../asset/images/education/thumb/0401.jpg',
		inTit1: 'Foreign tourist, MOU institution, affiliated groups',
		inTit2: 'Busan National Gugak Center Traditional Music Orchestra',
		inTit3: '10,000won per person',
		link: '0401.html'
	},
];