let schedule = [
	{
		day: '10',
		week: '화 TUE',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '11',
		week: '수 WED',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '12',
		week: '목 THU',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '13',
		week: '금 FRI',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '14',
		week: '토 SAT',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '28',
		week: '토 SAT',
		category: 'Ordinary person',
		title: '2023 the First Half Saturday Lecture, Story Festival <Deom Deom Deom(More More Better)>',
		imgSrc: '../../asset/images/education/thumb/0205.jpg',
		inTit1: 'Open to All',
		inTit2: '-',
		inTit3: 'Free',
		link: '0205.html'
	},
];
	