let schedule = [
	{
		day: '1',
		week: '화 TUE',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '2',
		week: '수 WED',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '3',
		week: '목 THU',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '4',
		week: '금 FRI',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '5',
		week: '토 SAT',
		category: 'Educational expert',
		title: 'Gugak Training for Teachers',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: 'Elementary, Middle, and High school Teachers',
		inTit2: 'Busan National Gugak Center Musicians, Invited instructors',
		inTit3: '30,000won',
		link: '0101.html'
	},
	{
		day: '5',
		week: '토 SAT',
		category: 'Ordinary person',
		title: 'Talk with Masters',
		imgSrc: '../../asset/images/education/thumb/0203.jpg',
		inTit1: 'Busan local resident',
		inTit2: 'Gugak Specialists',
		inTit3: 'Free',
		link: '0203.html'
	},
];