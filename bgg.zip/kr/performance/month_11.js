let schedule = [
	{
		day: '1',
		week: '수 WED',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '2',
		week: '목 THU',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '3',
		week: '금 FRI',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '4',
		week: '토 SAT',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '24',
		week: '금 FRI',
		category: '교류공연',
		title: '국립민속국악원 교류공연 <별난각시>',
		imgSrc: '../../asset/images/performance/thumb/0603.jpg',
		inTit1: '11.24.(금) ~ 11.25.(토) 주중 19:30  주말 17:00',
		inTit2: '연악당',
		inTit3: 'S석 10,000원 A석 8,000원',
		link: '0603.html'
	},
	{
		day: '25',
		week: '토 SAT',
		category: '교류공연',
		title: '국립민속국악원 교류공연 <별난각시>',
		imgSrc: '../../asset/images/performance/thumb/0603.jpg',
		inTit1: '11.24.(금) ~ 11.25.(토) 주중 19:30  주말 17:00',
		inTit2: '연악당',
		inTit3: 'S석 10,000원 A석 8,000원',
		link: '0603.html'
	},
];