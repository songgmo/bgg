let schedule = [
	{
		day: '13',
		week: '금 FRI',
		category: '기획공연',
		title: '국악대학축제 <지음知音>',
		imgSrc: '../../asset/images/performance/thumb/0306.jpg',
		inTit1: '10.13.(금) 19:30',
		inTit2: '연악당',
		inTit3: '전석무료',
		link: '0306.html'
	},
	{
		day: '27',
		week: '금 FRI',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '28',
		week: '토 SAT',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
	{
		day: '31',
		week: '화 TUE',
		category: '대표공연',
		title: '대표공연 <동래(가칭)>',
		imgSrc: '../../asset/images/performance/thumb/0101.jpg',
		inTit1: '10.27.(금) ~ 11.4.(토) 주중 19:30 주말 15:00',
		inTit2: '연악당',
		inTit3: 'S석 20,000원 A석 10,000원',
		link: '0101.html'
	},
];