let schedule = [
	{
		day: '7',
		week: '토 SAT',
		category: '기획공연',
		title: '새해맞이 &#60;굿(GOOD)이로구나!&#62;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(토), 1.14.(토), 1.28.(토) 15:00',
		inTit2: '연악당',
		inTit3: 'S석 10,000원 A석 8,000원',
		link: '0301.html'
	},
	{
		day: '14',
		week: '토 SAT',
		category: '기획공연',
		title: '새해맞이 &#60;굿(GOOD)이로구나!&#62;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(토), 1.14.(토), 1.28.(토) 15:00',
		inTit2: '연악당',
		inTit3: 'S석 10,000원 A석 8,000원',
		link: '0301.html'
	},
	{
		day: '21',
		week: '토 SAT',
		category: '명절공연',
		title: '설공연 &#60;흑토끼 연희 판판판&#62;',
		imgSrc: '../../asset/images/performance/thumb/0501.jpg',
		inTit1: '1.21.(토) ~ 1.22.(일) 15:00',
		inTit2: '연악당',
		inTit3: '전석 10,000원',
		link: '0501.html'
	},
	{
		day: '22',
		week: '일 SUN',
		category: '명절공연',
		title: '설공연 &#60;흑토끼 연희 판판판&#62;',
		imgSrc: '../../asset/images/performance/thumb/0501.jpg',
		inTit1: '1.21.(토) ~ 1.22.(일) 15:00',
		inTit2: '연악당',
		inTit3: '전석 10,000원',
		link: '0501.html'
	},
	{
		day: '28',
		week: '일 SUN',
		category: '기획공연',
		title: '새해맞이 &#60;굿(GOOD)이로구나!&#62;',
		imgSrc: '../../asset/images/performance/thumb/0301.jpg',
		inTit1: '1.7.(토), 1.14.(토), 1.28.(토) 15:00',
		inTit2: '연악당',
		inTit3: 'S석 10,000원 A석 8,000원',
		link: '0301.html'
	},
	];
	