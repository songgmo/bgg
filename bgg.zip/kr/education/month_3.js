let schedule = [
	{
		day: '11',
		week: '토 SAT',
		category: '일반인',
		title: '2023 상반기 토요강연 이야기마당 <덤덤덤> ',
		imgSrc: '../../asset/images/education/thumb/0205.jpg',
		inTit1: '누구나',
		inTit2: '명사초청',
		inTit3: '무료',
		link: '0205.html'
	},
];
	