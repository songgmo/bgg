let schedule = [
	{
		day: '22',
		week: '토 SAT',
		category: '일반인',
		title: '명사 초청 특강',
		imgSrc: '../../asset/images/education/thumb/0203.jpg',
		inTit1: '부산 지역 주민',
		inTit2: '유명 국악인',
		inTit3: '무료',
		link: '0203.html'
	},
];