let schedule = [
	{
		day: '1',
		week: '화 TUE',
		category: '교육전문가',
		title: '교사 국악직무연수 ',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: '전국 초중등 교원',
		inTit2: '국립부산국악원 연주단원, 외부 강사',
		inTit3: '30,000원',
		link: '0101.html'
	},
	{
		day: '2',
		week: '수 WED',
		category: '교육전문가',
		title: '교사 국악직무연수 ',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: '전국 초중등 교원',
		inTit2: '국립부산국악원 연주단원, 외부 강사',
		inTit3: '30,000원',
		link: '0101.html'
	},
	{
		day: '3',
		week: '목 THU',
		category: '교육전문가',
		title: '교사 국악직무연수 ',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: '전국 초중등 교원',
		inTit2: '국립부산국악원 연주단원, 외부 강사',
		inTit3: '30,000원',
		link: '0101.html'
	},
	{
		day: '4',
		week: '금 FRI',
		category: '교육전문가',
		title: '교사 국악직무연수 ',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: '전국 초중등 교원',
		inTit2: '국립부산국악원 연주단원, 외부 강사',
		inTit3: '30,000원',
		link: '0101.html'
	},
	{
		day: '5',
		week: '토 SAT',
		category: '교육전문가',
		title: '교사 국악직무연수 ',
		imgSrc: '../../asset/images/education/thumb/0101.jpg',
		inTit1: '전국 초중등 교원',
		inTit2: '국립부산국악원 연주단원, 외부 강사',
		inTit3: '30,000원',
		link: '0101.html'
	},
	{
		day: '5',
		week: '토 SAT',
		category: '일반인',
		title: '명사 초청 특강',
		imgSrc: '../../asset/images/education/thumb/0203.jpg',
		inTit1: '부산 지역 주민',
		inTit2: '유명 국악인',
		inTit3: '무료',
		link: '0203.html'
	},
];